package com.example.mid_project_2;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import androidx.appcompat.app.AppCompatActivity;
import java.io.Serializable;
import java.util.Calendar;

//資料儲存的結構
class Task implements Serializable {
    private String date;
    private String time;
    private String description;

    public Task(String date, String time, String description) {
        this.date = date;
        this.time = time;
        this.description = description;
    }

    // Getter and setter methods

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}

//
public class AddTodoActivity extends AppCompatActivity {
    EditText dateEditText, timeEditText, taskEditText;
    Button addTaskButton;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_todo);
        dateEditText = findViewById(R.id.dateEditText);
        timeEditText = findViewById(R.id.timeEditText);
        taskEditText = findViewById(R.id.taskEditText);
        addTaskButton = findViewById(R.id.addTaskButton);

        dateEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });

        timeEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog();
            }
        });

        addTaskButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 獲取用戶輸入的任務信息
                String date = dateEditText.getText().toString();
                String time = timeEditText.getText().toString();
                String task = taskEditText.getText().toString();

                // 創建一個新的任務對象
                Task newTask = new Task(date, time, task);

                // 將新的Task對象作為額外的數據傳遞到MainActivity
                Intent intent = new Intent();
                intent.putExtra("newTask", newTask);
                setResult(Activity.RESULT_OK, intent);
                finish(); // 結束AddTodoActivity
            }
        });
    }

    private void showDatePickerDialog() {
        // 獲取當前日期
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        // 創建日期對話框
        DatePickerDialog datePickerDialog = new DatePickerDialog(AddTodoActivity.this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        // 當用戶選擇日期時執行的操作
                        dateEditText.setText(year + "-" + (month + 1) + "-" + dayOfMonth);
                    }
                }, year, month, day);

        // 顯示日期對話框
        datePickerDialog.show();
    }

    private void showTimePickerDialog() {
        // 獲取當前時間
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        // 創建時間對話框
        TimePickerDialog timePickerDialog = new TimePickerDialog(AddTodoActivity.this,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        // 當用戶選擇時間時執行的操作
                        timeEditText.setText(hourOfDay + ":" + minute);
                    }
                }, hour, minute, true); // true表示24小時制

        // 顯示時間對話框
        timePickerDialog.show();
    }


}