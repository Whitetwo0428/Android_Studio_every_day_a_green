package com.example.mid_project_2;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class TaskActivity extends AppCompatActivity {
    RecyclerView recyclerView;

    List<Task> taskList;

    TaskAdapter taskAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task);

        recyclerView = findViewById(R.id.taskRecyclerView);
        taskList = new ArrayList<>();

        // 從MainActivity獲取TaskList
        taskList = (List<Task>) getIntent().getSerializableExtra("taskList");


        //saveTasks();
        // 初始化RecyclerView和Adapter

        taskAdapter = new TaskAdapter(taskList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(taskAdapter);

        //通知Adapter刷新數據
        //taskAdapter.notifyDataSetChanged();
    }

}
