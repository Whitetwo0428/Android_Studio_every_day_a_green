package com.example.mid_project_2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {
    List<Task> taskList;

    // Adapter的構造方法，用於接收數據列表
    public TaskAdapter(List<Task> taskList) {
        this.taskList = taskList;
    }

    // 創建ViewHolder
    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.task_item_layout, parent, false);
        return new TaskViewHolder(itemView);
    }

    // 綁定數據到ViewHolder上
    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = taskList.get(position);
        holder.descriptionTextView.setText("任務:" + task.getDescription()
                + "時間:" + task.getDate() + "\t" + task.getTime());
    }

    // 返回列表項目的數量
    @Override
    public int getItemCount() {
        return taskList.size();
    }

    // 自定義的ViewHolder類
    public static class TaskViewHolder extends RecyclerView.ViewHolder {
        public TextView descriptionTextView;

        public TaskViewHolder(View itemView) {
            super(itemView);
            //titleTextView = itemView.findViewById(R.id.titleTextView);
            descriptionTextView = itemView.findViewById(R.id.descriptionTextView);
        }
    }
}