package com.example.mid_project_2;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.Serializable;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    TaskManager taskManager;
    List<Task> taskList;
    TaskAdapter taskAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        taskManager = new TaskManager(this);
        taskList = taskManager.loadTasks();
        taskAdapter = new TaskAdapter(taskList);
    }

    public void onAddtodo(View view) {
        // 在MainActivity中啟動AddTodoActivity
        Intent intent = new Intent(MainActivity.this, AddTodoActivity.class);
        startActivityForResult(intent, 1); // 設置requestCode
    }

    public void saveTasks() {
        taskManager.saveTasks(taskList);
        Toast.makeText(this, "Tasks saved", Toast.LENGTH_SHORT).show();
    }

    public void onTask(View view) {
        Intent intent = new Intent(MainActivity.this, TaskActivity.class);
        intent.putExtra("taskList", (Serializable) taskList); // 將taskList作為額外的數據傳遞到TaskActivity
        startActivity(intent);
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                Task newTask = (Task) data.getSerializableExtra("newTask");
                if (newTask != null) {
                    // 將新增的Task對象添加到TaskList中
                    taskList.add(newTask);
                    // 通知Adapter刷新RecyclerView
                    taskAdapter.notifyDataSetChanged();
                    // 保存任務列表
                    saveTasks();
                }
            }
        }
    }
}

