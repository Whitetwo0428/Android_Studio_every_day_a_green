package com.example.mid_project_2;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class TaskManager {
    private static final String PREF_NAME = "TaskPrefs";
    private static final String KEY_TASK_LIST = "taskList";

    private SharedPreferences preferences;
    private Gson gson;

    public TaskManager(Context context) {
        preferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
    }

    public void saveTasks(List<Task> taskList) {
        SharedPreferences.Editor editor = preferences.edit();
        String tasksJson = gson.toJson(taskList);
        editor.putString(KEY_TASK_LIST, tasksJson);
        editor.apply();
    }

    public List<Task> loadTasks() {
        String tasksJson = preferences.getString(KEY_TASK_LIST, null);
        if (tasksJson != null) {
            Type type = new TypeToken<List<Task>>() {}.getType();
            return gson.fromJson(tasksJson, type);
        }
        return new ArrayList<>();
    }
}
